import React, { useState } from 'react';
import { useResetPassword } from '@nhost/react';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, Send, CheckCircle, AlertTriangle } from 'lucide-react';

const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const { resetPassword, isLoading, isSent, error } = useResetPassword();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        await resetPassword(email, {
            redirectTo: `${window.location.origin}/reset-password`
        });
        await resetPassword(email);
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
            <div className="max-w-md w-full bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8">
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">Forgot Password?</h1>
                    <p className="text-gray-600">
                        {isSent
                            ? "We've sent a link to your email."
                            : "Enter your email to receive a password reset link."
                        }
                    </p>
                </div>

                {isSent ? (
                    <div className="text-center">
                        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                        <p className="text-gray-700 text-lg mb-6">
                            A password reset link has been sent to <strong>{email}</strong>. Please check your inbox.
                        </p>
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <Mail className="h-5 w-5 text-gray-400" />
                            </div>
                            <input
                                type="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/50"
                                placeholder="Email address"
                            />
                        </div>

                        {error && (
                            <div className="bg-red-50 border border-red-200 rounded-xl p-3 flex items-start space-x-3">
                                <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0" />
                                <p className="text-red-600 text-sm">{error.message}</p>
                            </div>
                        )}

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-4 rounded-xl font-medium hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                        >
                            {isLoading ? (
                                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                            ) : (
                                <>
                                    <Send className="h-4 w-4" />
                                    <span>Send Reset Link</span>
                                </>
                            )}
                        </button>
                    </form>
                )}

                <div className="mt-8 text-center">
                    <Link
                        to="/signin"
                        className="text-blue-600 hover:text-blue-700 font-medium transition-colors flex items-center justify-center space-x-2"
                    >
                        <ArrowLeft className="h-4 w-4" />
                        <span>Back to Sign In</span>
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default ForgotPassword;
