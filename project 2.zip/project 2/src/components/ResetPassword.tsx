// src/components/ResetPassword.tsx

import React, { useState } from 'react';
import { useChangePassword } from '@nhost/react';
import { useNavigate } from 'react-router-dom';
import { Lock, Eye, EyeOff, CheckCircle } from 'lucide-react';

const ResetPassword = () => {
    const [newPassword, setNewPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [localError, setLocalError] = useState<string>('');
    const navigate = useNavigate();

    const { changePassword, isLoading, isSuccess, error } = useChangePassword();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLocalError('');

        // Optional: quick client-side validation
        if (!newPassword || newPassword.length < 3) {
            setLocalError('Password must be at least 3 characters.');
            return;
        }

        // IMPORTANT: pass an object, not a plain string
        const result = await changePassword(newPassword);

        // If backend validation fails, surface the message
        if (result.error) {
            setLocalError(result.error.message);
            return;
        }

        if (result.isSuccess) {
            // small delay is optional; you can navigate immediately if you prefer
            setTimeout(() => navigate('/signin'), 1200);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
            <div className="max-w-md w-full bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8">
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">Set New Password</h1>
                    <p className="text-gray-600">Create a new, strong password for your account.</p>
                </div>

                {isSuccess ? (
                    <div className="text-center">
                        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                        <p className="text-gray-700">Password updated successfully! Redirecting…</p>
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <Lock className="h-5 w-5 text-gray-400" />
                            </div>
                            <input
                                type={showPassword ? 'text' : 'password'}
                                required
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                                className="block w-full pl-10 pr-12 py-3 border border-gray-200 rounded-xl"
                                placeholder="New Password"
                            />
                            <button
                                type="button"
                                onClick={() => setShowPassword((s) => !s)}
                                className="absolute inset-y-0 right-0 pr-3 flex items-center"
                            >
                                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                            </button>
                        </div>

                        {(localError || error) && (
                            <p className="text-red-600 text-sm">
                                {localError || error?.message}
                            </p>
                        )}

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full bg-blue-600 text-white py-3 rounded-xl font-medium disabled:opacity-60"
                        >
                            {isLoading ? 'Updating…' : 'Update Password'}
                        </button>
                    </form>
                )}
            </div>
        </div>
    );
};

export default ResetPassword;