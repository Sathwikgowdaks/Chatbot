import { useUserData } from '@nhost/react';

const EmailVerifiedPage = () => {
    const userData = useUserData();

    if (userData?.emailVerified) {
        return <div>Registration Successful! Your email has been verified.</div>;
    } else {
        return <div>Your email verification is pending or failed.</div>;
    }
};

export default EmailVerifiedPage;